# CMake generated Testfile for 
# Source directory: /home/vito/prac_c++/homework/stack1/build-asan/_deps/googletest-src/googlemock
# Build directory: /home/vito/prac_c++/homework/stack1/build-asan/_deps/googletest-build/googlemock
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("../googletest")
